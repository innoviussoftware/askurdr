@extends('layouts.app')

@section('content')

<!-- Outer Row -->
<div class="row justify-content-center mt-3">

  <div class="col-xl-5 col-lg-12 col-md-9 mt-5">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-12">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">
                  <img src="{!! asset('public/logo.png') !!}" class="img-fluid mb-3" width="95"/>
                  <br>{{ __('Login') }}
                </h1>
              </div>
              
              <form method="POST" class="user user-validation" action="{{ route('login') }}" id="userform" >
                  @csrf
                <div class="form-group">
                  <input id="email" type="email" class="form-control-user form-control {{ $errors->has('email')?'is-invalid' : ''}}" name="email" value="{{ old('email') }}" autofocus placeholder="Please enter email address" autocomplete="off">
                  @if ($errors->has('email'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                  @endif
                </div>
                <div class="form-group">
                  <input id="password" type="password" class="form-control-user form-control {{ $errors->has('password')?'is-invalid' : ''}}" name="password"  placeholder="Please enter password" autocomplete="off">
                  @if ($errors->has('password'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('password') }}</strong>
                    </span>
                  @endif
                </div>
                <div class="form-group">
                  <div class="custom-control custom-checkbox small">
                    <input type="checkbox" class="custom-control-input" id="remember" {{ old('remember')?'checked' : ''}}>
                    <label class="custom-control-label" for="remember">Keep me logged in on this computer</label>
                  </div>
                </div>
                <button type="submit" class="btn btn-warning btn-user btn-block" style="font-size: 18px;text-align: left;">
                    {{ __('Login') }}<i class="pt-1 float-right fas fa-sign-in-alt"></i>
                </button>
                <hr>
              </form>
              <div class="text-center">
                @if (Route::has('password.request'))
                  <a class="small" href="{{ route('password.request') }}">
                    {{ __('Forgot Your Password?') }}
                  </a>
                @endif
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

</div>

@endsection
