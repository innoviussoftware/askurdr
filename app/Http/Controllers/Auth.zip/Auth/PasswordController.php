<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;
use DB;
use Auth;
use Hash;
use App\User;
use App\EmailTemplate;
use App\Notifications\MailResetPasswordNotification;

class PasswordController extends Controller
{
    public function sendPasswordResetToken(Request $request)
    {
        $user = User::where ('email', $request->email)->first();
        if ( !$user ) return redirect()->back()->withErrors(['error' => trans('admin.email_address_not_exists')]);

        DB::table('password_resets')->where('email', $request->email)->delete();

        //create a new token to be sent to the user.
        DB::table('password_resets')->insert([
            'email' => $request->email,
            'token' => str_random(60), //change 60 to any length you want
            'created_at' => date('Y-m-d h:i:s')
        ]);

        $tokenData = DB::table('password_resets')
        ->where('email', $request->email)->first();

       $token = $tokenData->token;
       $email = $request->email; // or $email = $tokenData->email;

       $link = url("/password/reset/?token=" . $token);
       

       $user_roles = $user->roles()->first();
       if($user_roles->id == 4 || $user_roles->id == 6){
            $code = 5;  // Customer & Tenants
        }
        elseif($user_roles->id == 5){
            $code = 6;  // Provider
        }else{
            $code = 4;   // Admin
        }

     //  if(EmailTemplate::where('code',$code)->where('status',1)->count() > 0){
           try {
            $user->notify(new MailResetPasswordNotification($token,$user));           
           } catch (Exception $e) {
               
           }
       //}
       
       return redirect()->back()->with('status',trans('admin.reset_email_link_sent'));

    }

    public function resetPassword(Request $request)
    {
         $password = $request->password;
         $token = $request->token;
         $tokenData = DB::table('password_resets')
         ->where('token', $token)->first();
         if ( !$tokenData ) return redirect()->back()->with('danger',trans('admin.reset_link_expired')); //or wherever you want
         $user = User::where('email', $tokenData->email)->first();
         if ( !$user ) return redirect()->to('login'); //or wherever you want

         $user->password = Hash::make($password);
         $user->update(); //or $user->save();

         //do we log the user directly or let them login and try their password for the first time ? if yes
         Auth::login($user);

        // If the user shouldn't reuse the token later, delete the token
        DB::table('password_resets')->where('email', $user->email)->delete();

        //redirect where we want according to whether they are logged in or not.
        return redirect()->route('logout');
    }

    public function showPasswordResetForm($token)
    {
        return view('auth.passwords.reset',['token'=>$token]);
    }
}
